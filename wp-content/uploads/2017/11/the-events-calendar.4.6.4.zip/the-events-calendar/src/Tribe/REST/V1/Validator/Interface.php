<?php


interface Tribe__Events__REST__V1__Validator__Interface  extends Tribe__Events__Validator__Interface {

}