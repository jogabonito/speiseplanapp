<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__File_Uploader' );


	class TribeEventsImporter_FileUploader extends Tribe__Events__Importer__File_Uploader {

	}