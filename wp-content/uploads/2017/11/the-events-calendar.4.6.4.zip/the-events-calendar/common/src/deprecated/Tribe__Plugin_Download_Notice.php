<?php
_deprecated_file( __FILE__, '4.3', 'Tribe__Admin__Notice__Plugin_Download.php' );

class Tribe__Plugin_Download_Notice extends Tribe__Admin__Notice__Plugin_Download {}