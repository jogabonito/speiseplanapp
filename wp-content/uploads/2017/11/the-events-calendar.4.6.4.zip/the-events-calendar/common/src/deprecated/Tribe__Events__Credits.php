<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Credits.php' );

class Tribe__Events__Credits extends Tribe__Credits {}
